export const rooms = [
    {
        "name": "First Class Room",
        "image": "first-class.jpg",
        "description": "<p>First Class Room cras dui sapien, feugiat vitae tristique ut, lobortis tempor orci. Donec pulvinar sagittis metus ut tristique. Pellentes que habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas idios.</p><span class=\"rate\">Rate: 220 / Day</span>"
    },
    {
        "name": "Deluxe Room",
        "image": "deluxe.jpg",
        "description": "<p>Deluxe Room sed et augue lorem. In sit amet placerat arcu. Mauris volutpat ipsum ac justo mollis vel vestibulum orci gravida. Vestibulum sit amet porttitor odio. Nulla facilisi. Fusce at pretium felis.</p><span class=\"rate\">Rate: 150 / Day</span>"
    },
    {
        "name": "Suite Room",
        "image": "suite.jpg",
        "description": "<p>Sed et augue lorem. In sit amet placerat arcu. Mauris volutpat ipsum ac justo mollis vel vestibulum orci gravida. Vestibulum sit amet porttitor odio. Nulla facilisi. Fusce at pretium felis.</p><span class=\"rate\">Rate: 180 / Day</span>"
    }
]