export const meals = [
    {
        "name": "SeaFood Special",
        "image": "seafoods.jpg",
        "description": "<p><span>Fried Salmon Special</span> I'm a product overview. Here you can write more information about your product. Buyers like to know ...</p>"
    },
    {
        "name": "Sumptuous Desserts",
        "image": "desserts.jpg",
        "description": "<p><span>Choco Ice Cream Sandwich</span> I'm a product overview. Here you can write more information about your product. Buyers like to know ...</p>"
    },
    {
        "name": "Buffet",
        "image": "buffet.jpg",
        "description": "<p><span>Mixed Buffet</span> I'm a product overview. Here you can write more information about your product. Buyers like to know ...</p>"
    }
]