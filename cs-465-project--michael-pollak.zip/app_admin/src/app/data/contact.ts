export const contacts = {
    "name": "Travlr Getaways",
    "address": "123 Lorem Ipsum Cove, Sed Ut City, LI 12345",
    "phoneNumber": "1-800-999-9999",
    "faxNumber": "1-800-111-1111"
}